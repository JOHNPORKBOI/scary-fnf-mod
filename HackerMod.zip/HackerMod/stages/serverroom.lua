function onCreate()
    makeLuaSprite('room', 'hack/serverroom', -1000, -480)
    setScrollFactor('room', 0.95, 0.95)
    addLuaSprite('room', false)
end
