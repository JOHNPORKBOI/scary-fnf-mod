-- THE HACKER: voices follow the melody, mid-song hack opens Notepad with "U CANT ESCAPE"
-- Set this to false if you want everything to stay inside the game (no real Notepad window).
local USE_NOTEPAD = true

local voiceMap = {
    [3200] = 'h_57_s_yo',
    [3400] = 'h_64_s_go',
    [3500] = 'h_62_s_yeah',
    [3600] = 'h_60_s_bop',
    [3800] = 'h_57_s_uh',
    [4000] = 'h_60_s_ski',
    [4100] = 'h_62_s_ya',
    [4200] = 'h_64_s_ba',
    [4400] = 'h_67_s_bop',
    [4500] = 'h_64_s_hey',
    [4600] = 'h_62_s_ba',
    [4800] = 'h_57_s_yo',
    [5000] = 'h_64_s_go',
    [5100] = 'h_62_s_yeah',
    [5200] = 'h_60_s_bop',
    [5400] = 'h_57_s_uh',
    [5600] = 'h_60_s_ski',
    [5700] = 'h_62_s_ya',
    [5800] = 'h_64_s_ba',
    [6000] = 'h_67_s_bop',
    [6100] = 'h_64_s_hey',
    [6200] = 'h_62_s_ba',
    [9600] = 'h_69_s_ba',
    [9700] = 'h_64_s_ski',
    [9800] = 'h_67_s_yo',
    [9900] = 'h_64_s_go',
    [10000] = 'h_65_s_da',
    [10200] = 'h_64_s_da',
    [10300] = 'h_62_s_go',
    [10400] = 'h_60_l_ski',
    [10700] = 'h_62_s_da',
    [10800] = 'h_64_s_hey',
    [10900] = 'h_60_s_ya',
    [11000] = 'h_57_s_ski',
    [11200] = 'h_69_s_ba',
    [11300] = 'h_64_s_ski',
    [11400] = 'h_67_s_yo',
    [11500] = 'h_64_s_go',
    [11600] = 'h_65_s_da',
    [11800] = 'h_64_s_da',
    [11900] = 'h_62_s_go',
    [12000] = 'h_60_l_ski',
    [12300] = 'h_62_s_da',
    [12400] = 'h_64_s_hey',
    [12500] = 'h_60_s_ya',
    [12600] = 'h_57_s_ski',
    [16000] = 'h_57_s_yo',
    [16200] = 'h_64_s_go',
    [16300] = 'h_62_s_yeah',
    [16400] = 'h_60_s_bop',
    [16600] = 'h_57_s_uh',
    [16800] = 'h_60_s_ski',
    [16900] = 'h_62_s_ya',
    [17000] = 'h_64_s_ba',
    [17200] = 'h_67_s_bop',
    [17300] = 'h_64_s_hey',
    [17400] = 'h_62_s_ba',
    [17600] = 'h_57_s_yo',
    [17800] = 'h_64_s_go',
    [17900] = 'h_62_s_yeah',
    [18000] = 'h_60_s_bop',
    [18200] = 'h_57_s_uh',
    [18400] = 'h_60_s_ski',
    [18500] = 'h_62_s_ya',
    [18600] = 'h_64_s_ba',
    [18800] = 'h_67_s_bop',
    [18900] = 'h_64_s_hey',
    [19000] = 'h_62_s_ba',
    [22400] = 'h_57_s_yo',
    [22500] = 'h_69_s_ba',
    [22600] = 'h_57_s_ba',
    [22700] = 'h_67_s_yo',
    [22800] = 'h_57_s_hey',
    [22900] = 'h_65_s_da',
    [23000] = 'h_64_s_da',
    [23200] = 'h_62_s_ya',
    [23300] = 'h_60_s_ski',
    [23400] = 'h_62_s_da',
    [23500] = 'h_64_s_ba',
    [23600] = 'h_69_l_ski',
    [23900] = 'h_67_s_yeah',
    [24000] = 'h_57_s_yo',
    [24100] = 'h_69_s_ba',
    [24200] = 'h_57_s_ba',
    [24300] = 'h_67_s_yo',
    [24400] = 'h_57_s_hey',
    [24500] = 'h_65_s_da',
    [24600] = 'h_64_s_da',
    [24800] = 'h_62_s_ya',
    [24900] = 'h_60_s_ski',
    [25000] = 'h_62_s_da',
    [25100] = 'h_64_s_ba',
    [25200] = 'h_69_l_ski',
    [25500] = 'h_67_s_yeah'
}
local redMap = {
    [32000] = 'r_57_s_yo',
    [32100] = 'r_69_s_ba',
    [32200] = 'r_57_s_ba',
    [32300] = 'r_70_s_uh',
    [32400] = 'r_57_s_hey',
    [32500] = 'r_69_s_uh',
    [32600] = 'r_67_s_hey',
    [32700] = 'r_65_s_yo',
    [32800] = 'r_64_s_yo',
    [32900] = 'r_65_s_ba',
    [33000] = 'r_64_s_ba',
    [33100] = 'r_62_s_da',
    [33200] = 'r_60_s_ya',
    [33300] = 'r_58_s_ski',
    [33400] = 'r_57_s_ski',
    [33500] = 'r_69_s_go',
    [33600] = 'r_57_s_yo',
    [33700] = 'r_69_s_ba',
    [33800] = 'r_57_s_ba',
    [33900] = 'r_70_s_uh',
    [34000] = 'r_57_s_hey',
    [34100] = 'r_69_s_uh',
    [34200] = 'r_67_s_hey',
    [34300] = 'r_65_s_yo',
    [34400] = 'r_64_s_yo',
    [34500] = 'r_65_s_ba',
    [34600] = 'r_64_s_ba',
    [34700] = 'r_62_s_da',
    [34800] = 'r_60_s_ya',
    [34900] = 'r_58_s_ski',
    [35000] = 'r_57_s_ski',
    [35100] = 'r_69_s_go',
    [38400] = 'r_69_s_ba',
    [38600] = 'r_70_s_uh',
    [38700] = 'r_69_s_hey',
    [38800] = 'r_67_s_ba',
    [38900] = 'r_65_s_da',
    [39000] = 'r_64_s_da',
    [39200] = 'r_65_s_ba',
    [39300] = 'r_64_s_yo',
    [39400] = 'r_62_s_da',
    [39500] = 'r_60_s_go',
    [39600] = 'r_58_s_ski',
    [39800] = 'r_57_s_ski',
    [39900] = 'r_58_s_go',
    [40000] = 'r_69_s_ba',
    [40200] = 'r_70_s_uh',
    [40300] = 'r_69_s_hey',
    [40400] = 'r_67_s_ba',
    [40500] = 'r_65_s_da',
    [40600] = 'r_64_s_da',
    [40800] = 'r_65_s_ba',
    [40900] = 'r_64_s_yo',
    [41000] = 'r_62_s_da',
    [41100] = 'r_60_s_go',
    [41200] = 'r_58_s_ski',
    [41400] = 'r_57_s_ski',
    [41500] = 'r_58_s_go',
    [44800] = 'r_57_s_yo',
    [44900] = 'r_69_s_ba',
    [45000] = 'r_57_s_ba',
    [45100] = 'r_70_s_uh',
    [45200] = 'r_57_s_hey',
    [45300] = 'r_69_s_uh',
    [45400] = 'r_67_s_hey',
    [45500] = 'r_65_s_yo',
    [45600] = 'r_64_s_yo',
    [45700] = 'r_65_s_ba',
    [45800] = 'r_64_s_ba',
    [45900] = 'r_62_s_da',
    [46000] = 'r_60_s_ya',
    [46100] = 'r_58_s_ski',
    [46200] = 'r_57_s_ski',
    [46300] = 'r_69_s_go',
    [46400] = 'r_57_s_yo',
    [46500] = 'r_69_s_ba',
    [46600] = 'r_57_s_ba',
    [46700] = 'r_70_s_uh',
    [46800] = 'r_57_s_hey',
    [46900] = 'r_69_s_uh',
    [47000] = 'r_67_s_hey',
    [47100] = 'r_65_s_yo',
    [47200] = 'r_64_s_yo',
    [47300] = 'r_65_s_ba',
    [47400] = 'r_64_s_ba',
    [47500] = 'r_62_s_da',
    [47600] = 'r_60_s_ya',
    [47700] = 'r_58_s_ski',
    [47800] = 'r_57_s_ski',
    [47900] = 'r_69_s_go',
    [51200] = 'r_69_s_ba',
    [51400] = 'r_70_s_uh',
    [51500] = 'r_69_s_hey',
    [51600] = 'r_67_s_ba',
    [51700] = 'r_65_s_da',
    [51800] = 'r_64_s_da',
    [52000] = 'r_65_s_ba',
    [52100] = 'r_64_s_yo',
    [52200] = 'r_62_s_da',
    [52300] = 'r_60_s_go',
    [52400] = 'r_58_s_ski',
    [52600] = 'r_57_s_ski',
    [52700] = 'r_58_s_go',
    [52800] = 'r_69_s_ba',
    [53000] = 'r_70_s_uh',
    [53100] = 'r_69_s_hey',
    [53200] = 'r_67_s_ba',
    [53300] = 'r_65_s_da',
    [53400] = 'r_64_s_da',
    [53600] = 'r_65_s_ba',
    [53700] = 'r_64_s_yo',
    [53800] = 'r_62_s_da',
    [53900] = 'r_60_s_go',
    [54000] = 'r_58_s_ski',
    [54200] = 'r_57_s_ski',
    [54300] = 'r_58_s_go',
    [57600] = 'r_57_s_yo',
    [57700] = 'r_58_s_ba',
    [57800] = 'r_60_s_wa',
    [57900] = 'r_58_s_hey',
    [58000] = 'r_64_s_ya',
    [58100] = 'r_65_s_da',
    [58200] = 'r_64_s_da',
    [58300] = 'r_60_s_yeah',
    [58400] = 'r_69_s_bop',
    [58500] = 'r_70_s_yeah',
    [58600] = 'r_69_s_yeah',
    [58700] = 'r_65_s_hey',
    [58800] = 'r_64_s_hey',
    [58900] = 'r_60_s_ya',
    [59000] = 'r_58_s_go',
    [59100] = 'r_57_s_ski',
    [59200] = 'r_57_s_yo',
    [59300] = 'r_58_s_ba',
    [59400] = 'r_60_s_wa',
    [59500] = 'r_58_s_hey',
    [59600] = 'r_64_s_ya',
    [59700] = 'r_65_s_da',
    [59800] = 'r_64_s_da',
    [59900] = 'r_60_s_yeah',
    [60000] = 'r_69_s_bop',
    [60100] = 'r_70_s_yeah',
    [60200] = 'r_69_s_yeah',
    [60300] = 'r_65_s_hey',
    [60400] = 'r_64_s_hey',
    [60500] = 'r_60_s_ya',
    [60600] = 'r_58_s_go',
    [60700] = 'r_57_s_ski'
}
local bfMap = {
    [6400] = 'bf_69_s_bop',
    [6600] = 'bf_76_s_ba',
    [6700] = 'bf_74_s_bep',
    [6800] = 'bf_72_s_da',
    [7000] = 'bf_69_s_bee',
    [7200] = 'bf_72_s_bop',
    [7300] = 'bf_74_s_skee',
    [7400] = 'bf_76_s_da',
    [7600] = 'bf_79_s_skee',
    [7700] = 'bf_76_s_bep',
    [7800] = 'bf_74_s_da',
    [8000] = 'bf_69_s_bop',
    [8200] = 'bf_76_s_ba',
    [8300] = 'bf_74_s_bep',
    [8400] = 'bf_72_s_da',
    [8600] = 'bf_69_s_bee',
    [8800] = 'bf_72_s_bop',
    [8900] = 'bf_74_s_skee',
    [9000] = 'bf_76_s_da',
    [9200] = 'bf_79_s_skee',
    [9300] = 'bf_76_s_bep',
    [9400] = 'bf_74_s_da',
    [12800] = 'bf_81_s_da',
    [12900] = 'bf_76_s_bop',
    [13000] = 'bf_79_s_bap',
    [13100] = 'bf_76_s_ba',
    [13200] = 'bf_77_s_bee',
    [13400] = 'bf_76_s_bee',
    [13500] = 'bf_74_s_ba',
    [13600] = 'bf_72_l_bop',
    [13900] = 'bf_74_s_bee',
    [14000] = 'bf_76_s_bep',
    [14100] = 'bf_72_s_skee',
    [14200] = 'bf_69_s_bop',
    [14400] = 'bf_81_s_da',
    [14500] = 'bf_76_s_bop',
    [14600] = 'bf_79_s_bap',
    [14700] = 'bf_76_s_ba',
    [14800] = 'bf_77_s_bee',
    [15000] = 'bf_76_s_bee',
    [15100] = 'bf_74_s_ba',
    [15200] = 'bf_72_l_bop',
    [15500] = 'bf_74_s_bee',
    [15600] = 'bf_76_s_bep',
    [15700] = 'bf_72_s_skee',
    [15800] = 'bf_69_s_bop',
    [19200] = 'bf_69_s_bop',
    [19400] = 'bf_76_s_ba',
    [19500] = 'bf_74_s_bep',
    [19600] = 'bf_72_s_da',
    [19800] = 'bf_69_s_bee',
    [20000] = 'bf_72_s_bop',
    [20100] = 'bf_74_s_skee',
    [20200] = 'bf_76_s_da',
    [20400] = 'bf_79_s_skee',
    [20500] = 'bf_76_s_bep',
    [20600] = 'bf_74_s_da',
    [20800] = 'bf_69_s_bop',
    [21000] = 'bf_76_s_ba',
    [21100] = 'bf_74_s_bep',
    [21200] = 'bf_72_s_da',
    [21400] = 'bf_69_s_bee',
    [21600] = 'bf_72_s_bop',
    [21700] = 'bf_74_s_skee',
    [21800] = 'bf_76_s_da',
    [22000] = 'bf_79_s_skee',
    [22100] = 'bf_76_s_bep',
    [22200] = 'bf_74_s_da',
    [25600] = 'bf_69_s_bop',
    [25700] = 'bf_81_s_da',
    [25800] = 'bf_69_s_ba',
    [25900] = 'bf_79_s_bap',
    [26000] = 'bf_69_s_skee',
    [26100] = 'bf_77_s_bee',
    [26200] = 'bf_76_s_bee',
    [26400] = 'bf_74_s_skee',
    [26500] = 'bf_72_s_bop',
    [26600] = 'bf_74_s_bee',
    [26700] = 'bf_76_s_da',
    [26800] = 'bf_81_l_bap',
    [27100] = 'bf_79_s_bee',
    [27200] = 'bf_69_s_bop',
    [27300] = 'bf_81_s_da',
    [27400] = 'bf_69_s_ba',
    [27500] = 'bf_79_s_bap',
    [27600] = 'bf_69_s_skee',
    [27700] = 'bf_77_s_bee',
    [27800] = 'bf_76_s_bee',
    [28000] = 'bf_74_s_skee',
    [28100] = 'bf_72_s_bop',
    [28200] = 'bf_74_s_bee',
    [28300] = 'bf_76_s_da',
    [28400] = 'bf_81_l_bap',
    [28700] = 'bf_79_s_bee',
    [35200] = 'bf_69_s_bop',
    [35300] = 'bf_81_s_da',
    [35400] = 'bf_69_s_ba',
    [35500] = 'bf_82_s_bop',
    [35600] = 'bf_69_s_skee',
    [35700] = 'bf_81_s_bop',
    [35800] = 'bf_79_s_bep',
    [35900] = 'bf_77_s_bap',
    [36000] = 'bf_76_s_bap',
    [36100] = 'bf_77_s_da',
    [36200] = 'bf_76_s_da',
    [36300] = 'bf_74_s_bee',
    [36400] = 'bf_72_s_skee',
    [36500] = 'bf_70_s_bop',
    [36600] = 'bf_69_s_bop',
    [36700] = 'bf_81_s_da',
    [36800] = 'bf_69_s_bop',
    [36900] = 'bf_81_s_da',
    [37000] = 'bf_69_s_ba',
    [37100] = 'bf_82_s_bop',
    [37200] = 'bf_69_s_skee',
    [37300] = 'bf_81_s_bop',
    [37400] = 'bf_79_s_bep',
    [37500] = 'bf_77_s_bap',
    [37600] = 'bf_76_s_bap',
    [37700] = 'bf_77_s_da',
    [37800] = 'bf_76_s_da',
    [37900] = 'bf_74_s_bee',
    [38000] = 'bf_72_s_skee',
    [38100] = 'bf_70_s_bop',
    [38200] = 'bf_69_s_bop',
    [38300] = 'bf_81_s_da',
    [41600] = 'bf_81_s_da',
    [41800] = 'bf_82_s_bop',
    [41900] = 'bf_81_s_bep',
    [42000] = 'bf_79_s_da',
    [42100] = 'bf_77_s_bee',
    [42200] = 'bf_76_s_bee',
    [42400] = 'bf_77_s_da',
    [42500] = 'bf_76_s_bap',
    [42600] = 'bf_74_s_bee',
    [42700] = 'bf_72_s_ba',
    [42800] = 'bf_70_s_bop',
    [43000] = 'bf_69_s_bop',
    [43100] = 'bf_70_s_ba',
    [43200] = 'bf_81_s_da',
    [43400] = 'bf_82_s_bop',
    [43500] = 'bf_81_s_bep',
    [43600] = 'bf_79_s_da',
    [43700] = 'bf_77_s_bee',
    [43800] = 'bf_76_s_bee',
    [44000] = 'bf_77_s_da',
    [44100] = 'bf_76_s_bap',
    [44200] = 'bf_74_s_bee',
    [44300] = 'bf_72_s_ba',
    [44400] = 'bf_70_s_bop',
    [44600] = 'bf_69_s_bop',
    [44700] = 'bf_70_s_ba',
    [48000] = 'bf_69_s_bop',
    [48100] = 'bf_81_s_da',
    [48200] = 'bf_69_s_ba',
    [48300] = 'bf_82_s_bop',
    [48400] = 'bf_69_s_skee',
    [48500] = 'bf_81_s_bop',
    [48600] = 'bf_79_s_bep',
    [48700] = 'bf_77_s_bap',
    [48800] = 'bf_76_s_bap',
    [48900] = 'bf_77_s_da',
    [49000] = 'bf_76_s_da',
    [49100] = 'bf_74_s_bee',
    [49200] = 'bf_72_s_skee',
    [49300] = 'bf_70_s_bop',
    [49400] = 'bf_69_s_bop',
    [49500] = 'bf_81_s_da',
    [49600] = 'bf_69_s_bop',
    [49700] = 'bf_81_s_da',
    [49800] = 'bf_69_s_ba',
    [49900] = 'bf_82_s_bop',
    [50000] = 'bf_69_s_skee',
    [50100] = 'bf_81_s_bop',
    [50200] = 'bf_79_s_bep',
    [50300] = 'bf_77_s_bap',
    [50400] = 'bf_76_s_bap',
    [50500] = 'bf_77_s_da',
    [50600] = 'bf_76_s_da',
    [50700] = 'bf_74_s_bee',
    [50800] = 'bf_72_s_skee',
    [50900] = 'bf_70_s_bop',
    [51000] = 'bf_69_s_bop',
    [51100] = 'bf_81_s_da',
    [54400] = 'bf_69_s_bop',
    [54500] = 'bf_70_s_ba',
    [54600] = 'bf_72_s_bap',
    [54700] = 'bf_70_s_skee',
    [54800] = 'bf_76_s_skee',
    [54900] = 'bf_77_s_bee',
    [55000] = 'bf_76_s_bee',
    [55100] = 'bf_72_s_bep',
    [55200] = 'bf_81_s_skee',
    [55300] = 'bf_82_s_bee',
    [55400] = 'bf_81_s_bee',
    [55500] = 'bf_77_s_bep',
    [55600] = 'bf_76_s_bep',
    [55700] = 'bf_72_s_skee',
    [55800] = 'bf_70_s_ba',
    [55900] = 'bf_69_s_bop',
    [56000] = 'bf_69_s_bop',
    [56100] = 'bf_70_s_ba',
    [56200] = 'bf_72_s_bap',
    [56300] = 'bf_70_s_skee',
    [56400] = 'bf_76_s_skee',
    [56500] = 'bf_77_s_bee',
    [56600] = 'bf_76_s_bee',
    [56700] = 'bf_72_s_bep',
    [56800] = 'bf_81_s_skee',
    [56900] = 'bf_82_s_bee',
    [57000] = 'bf_81_s_bee',
    [57100] = 'bf_77_s_bep',
    [57200] = 'bf_76_s_bep',
    [57300] = 'bf_72_s_skee',
    [57400] = 'bf_70_s_ba',
    [57500] = 'bf_69_s_bop',
    [60800] = 'bf_69_s_bop',
    [60900] = 'bf_70_s_ba',
    [61000] = 'bf_72_s_bap',
    [61100] = 'bf_70_s_skee',
    [61200] = 'bf_76_s_skee',
    [61300] = 'bf_77_s_bee',
    [61400] = 'bf_76_s_bee',
    [61500] = 'bf_72_s_bep',
    [61600] = 'bf_81_s_skee',
    [61700] = 'bf_82_s_bee',
    [61800] = 'bf_81_s_bee',
    [61900] = 'bf_77_s_bep',
    [62000] = 'bf_76_s_bep',
    [62100] = 'bf_72_s_skee',
    [62200] = 'bf_70_s_ba',
    [62300] = 'bf_69_s_bop',
    [62400] = 'bf_69_s_bop',
    [62500] = 'bf_70_s_ba',
    [62600] = 'bf_72_s_bap',
    [62700] = 'bf_70_s_skee',
    [62800] = 'bf_76_s_skee',
    [62900] = 'bf_77_s_bee',
    [63000] = 'bf_76_s_bee',
    [63100] = 'bf_72_s_bep',
    [63200] = 'bf_81_s_skee',
    [63300] = 'bf_82_s_bee',
    [63400] = 'bf_81_s_bee',
    [63500] = 'bf_77_s_bep',
    [63600] = 'bf_76_s_bep',
    [63700] = 'bf_72_s_skee',
    [63800] = 'bf_70_s_ba',
    [63900] = 'bf_69_s_bop'
}
local dirs = {'left', 'down', 'up', 'right'}
local BREAK_STEP = 288
local P2_STEP = 320
local END_STEP = 640
local SCRAMBLE = {412, 448, 540, 576}
local NOTE_FILE = 'U_CANT_ESCAPE.txt'
local phase2, scrambled = false, false
local popN, t = 0, 0
local user = 'PLAYER'

local function active() return dadName == 'hacker' or dadName == 'hacker-red' end

local function openNotepad()
    if not USE_NOTEPAD or buildTarget ~= 'windows' then return false end
    if not (io and io.open and os and os.execute and os.time) then return false end
    local ok, res = pcall(function()
        local f = io.open(NOTE_FILE, 'r')
        if f then
            local c = f:read('*a'); f:close()
            local stamp = tonumber(string.match(c or '', '%[log (%d+)%]'))
            if stamp and os.time() - stamp < 600 then return false end   -- not again on every retry
        end
        f = io.open(NOTE_FILE, 'w')
        if not f then return false end
        f:write('U CANT ESCAPE\n\n')
        for i = 1, 12 do f:write(string.rep(' ', i * 2) .. 'U CANT ESCAPE, ' .. user .. '\n') end
        f:write('\n\ni am still in the game.\ngo back and finish the song.\n\n        - the hacker\n')
        f:write('\n\n\n(this file was made by the Hacker FNF mod. it is just a joke, nothing was hacked.)\n[log ' .. os.time() .. ']\n')
        f:close()
        os.execute('start "" notepad "' .. NOTE_FILE .. '"')
        return true
    end)
    return ok and res == true
end

function onCreate()
    addCharacterToList('hacker-red', 'dad')
    for _, s in ipairs({'hack_laugh', 'hack_glitch', 'hack_boom', 'hack_error'}) do precacheSound(s) end
    precacheImage('hack/error'); precacheImage('hack/fakepad')
    pcall(function() user = string.upper(os.getenv('USERNAME') or 'PLAYER') end)
end

function onCreatePost()
    if not active() then return end
    makeLuaSprite('void', '', -3000, -2500)
    makeGraphic('void', 9000, 7000, '000000')
    setProperty('void.alpha', 0)
    addLuaSprite('void', false)

    makeLuaSprite('static', 'hack/static', 0, 0)
    setGraphicSize('static', screenWidth, screenHeight)
    setObjectCamera('static', 'other')
    setProperty('static.alpha', 0)
    addLuaSprite('static', true)

    makeLuaSprite('scan', 'hack/scanlines', 0, 0)
    setObjectCamera('scan', 'other')
    setProperty('scan.alpha', 0.22)
    addLuaSprite('scan', true)

    makeLuaSprite('flash', '', 0, 0)
    makeGraphic('flash', screenWidth, screenHeight, 'FFFFFF')
    setObjectCamera('flash', 'other')
    setProperty('flash.alpha', 0)
    addLuaSprite('flash', true)

    makeLuaSprite('fakepad', 'hack/fakepad', 0, 0)
    setObjectCamera('fakepad', 'other')
    screenCenter('fakepad')
    setProperty('fakepad.alpha', 0)
    addLuaSprite('fakepad', true)

    makeLuaText('term', '', 900, 30, 470)
    setTextSize('term', 26); setTextColor('term', '46FF8C'); setTextAlignment('term', 'left')
    setObjectCamera('term', 'other')
    addLuaText('term')

    makeLuaText('big', 'U CANT ESCAPE', screenWidth, 0, 250)
    setTextSize('big', 120); setTextColor('big', 'FF2030'); setTextAlignment('big', 'center')
    setObjectCamera('big', 'other')
    setProperty('big.alpha', 0)
    addLuaText('big')
end

function onSongStart() setProperty('camZooming', true) end

local function flash(hex, a, time)
    setProperty('flash.color', getColorFromHex(hex))
    setProperty('flash.alpha', a)
    cancelTween('flashOut'); doTweenAlpha('flashOut', 'flash', 0, time, 'quadOut')
end

local function glitch(power)
    playSound('hack_glitch', 0.5 * power)
    setProperty('static.alpha', 0.55 * power)
    cancelTween('staticOut'); doTweenAlpha('staticOut', 'static', 0, 0.35, 'linear')
    cameraShake('game', 0.012 * power, 0.2); cameraShake('hud', 0.008 * power, 0.2)
    setProperty('camHUD.angle', getRandomFloat(-3, 3) * power)
    runTimer('unTilt', 0.12)
end

local function bump(g, h)
    setProperty('camGame.zoom', getProperty('camGame.zoom') + g)
    setProperty('camHUD.zoom', getProperty('camHUD.zoom') + h)
end

local function popup()
    popN = popN + 1
    local tag = 'pop' .. popN
    makeLuaSprite(tag, 'hack/error', getRandomInt(30, 520), getRandomInt(140, 470))
    setObjectCamera(tag, 'hud')
    addLuaSprite(tag, true)
    scaleObject(tag, 0.6, 0.6)
    doTweenX(tag .. 'SX', tag .. '.scale', 1, 0.12, 'backOut')
    doTweenY(tag .. 'SY', tag .. '.scale', 1, 0.12, 'backOut')
    doTweenAlpha(tag .. 'A', tag, 0, 0.9, 'quadIn')
    playSound('hack_error', 0.5)
end

function onTweenCompleted(tag)
    if string.sub(tag, 1, 3) == 'pop' and string.sub(tag, -1) == 'A' then removeLuaSprite(string.sub(tag, 1, -2), true) end
end

local function setScramble(on)
    scrambled = on
    for i = 0, 3 do
        local target = on and (3 - i) or i
        noteTweenX('scr' .. i, 4 + i, _G['defaultPlayerStrumX' .. target], 0.35, 'quadInOut')
    end
    if on then
        setTextString('term', '> input.scramble()'); glitch(0.8)
    else
        setTextString('term', '')
    end
end

local function noteKey(id) return math.floor(getPropertyFromGroup('notes', id, 'strumTime') + 0.5) end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    if not active() or isSustainNote then return end
    local key = noteKey(id)
    local snd = phase2 and redMap[key] or voiceMap[key]
    playSound(snd or ((phase2 and 'red_' or 'hk_') .. dirs[direction + 1]), 1)
    if phase2 then
        cameraShake('game', 0.007, 0.1)
        if getProperty('health') > 0.35 then setProperty('health', getProperty('health') - 0.017) end
        if getRandomBool(9) then popup() end
        if getRandomBool(6) then glitch(0.6) end
    else
        cameraShake('game', 0.003, 0.08)
    end
end

function goodNoteHit(id, direction, noteType, isSustainNote)
    if not active() or isSustainNote then return end
    playSound(bfMap[noteKey(id)] or ('bf_' .. dirs[direction + 1]), 0.95)
end

function onStepHit()
    if not active() then return end
    local s = curStep
    -- intro terminal
    if s == 2 then setTextString('term', '> connecting to ' .. user .. '-PC ...')
    elseif s == 14 then setTextString('term', '> connecting to ' .. user .. '-PC ...\n> ACCESS GRANTED'); glitch(0.5)
    elseif s == 30 then setTextString('term', '')
    end
    -- the hack
    local b = s - BREAK_STEP
    if b == 0 then
        triggerEvent('Play Animation', 'type', 'dad')
        doTweenAlpha('voidIn', 'void', 0.8, 0.6, 'quadOut')
        doTweenAlpha('hudDim', 'camHUD', 0.25, 0.5, 'quadOut')
        setProperty('defaultCamZoom', 1.0)
        setTextString('term', '> locating player ...'); glitch(0.7)
    elseif b == 5 then setTextString('term', '> locating player ...\n> found: ' .. user)
    elseif b == 9 then setTextString('term', '> locating player ...\n> found: ' .. user .. '\n> open notepad.exe'); glitch(0.5)
    elseif b == 13 then setTextString('term', '> locating player ...\n> found: ' .. user .. '\n> open notepad.exe\n> write("U CANT ESCAPE")')
    elseif b == 16 then
        triggerEvent('Play Animation', 'laugh', 'dad')
        playSound('hack_laugh', 1)
        setProperty('big.alpha', 1)
        setProperty('big.scale.x', 0.4); setProperty('big.scale.y', 0.4)
        doTweenX('bigX', 'big.scale', 1, 0.25, 'backOut'); doTweenY('bigY', 'big.scale', 1, 0.25, 'backOut')
        flash('FF2030', 0.6, 0.6); glitch(1)
        if not openNotepad() then
            setProperty('fakepad.alpha', 1)
            setProperty('big.y', 560); setTextSize('big', 70)
        end
    elseif b > 16 and b < 32 and b % 4 == 0 then
        glitch(0.6); setProperty('big.angle', getRandomFloat(-4, 4))
    end
    if s == P2_STEP then
        phase2 = true
        triggerEvent('Change Character', 'dad', 'hacker-red')
        triggerEvent('Play Animation', 'scared', 'bf')
        playSound('hack_boom', 1)
        setProperty('big.alpha', 0); setProperty('fakepad.alpha', 0)
        setTextString('term', ''); setTextColor('term', 'FF4050')
        setProperty('void.alpha', 0.55)
        doTweenAlpha('hudBack', 'camHUD', 1, 0.3, 'quadOut')
        setProperty('defaultCamZoom', 0.78)
        flash('FF2030', 1, 0.9)
        cameraShake('game', 0.03, 0.9); cameraShake('hud', 0.02, 0.9)
        for i = 0, 3 do setPropertyFromGroup('opponentStrums', i, 'color', getColorFromHex('FF4050')) end
        setHealthBarColors('FF2030', '31B0D1')
    end
    for i = 1, #SCRAMBLE, 2 do
        if s == SCRAMBLE[i] then setScramble(true) elseif s == SCRAMBLE[i + 1] then setScramble(false) end
    end
    if s == END_STEP then
        phase2 = false
        if scrambled then setScramble(false) end
        flash('FFFFFF', 0.8, 1.2)
        doTweenAlpha('voidOut', 'void', 0, 1.5, 'quadOut')
        setTextColor('term', '46FF8C'); setTextString('term', '> connection lost.')
    end
end

function onBeatHit()
    if not active() then return end
    if curStep < 32 or (curStep >= BREAK_STEP and curStep < P2_STEP) or curStep >= END_STEP then return end
    if phase2 then
        bump(curBeat % 2 == 0 and 0.03 or 0.015, 0.03)
        if curBeat % 16 == 0 then flash('FF2030', 0.3, 0.4); glitch(0.7) end
    else
        bump(curBeat % 4 == 0 and 0.025 or 0.01, 0.02)
    end
end

function onTimerCompleted(tag)
    if tag == 'unTilt' then setProperty('camHUD.angle', 0) end
end

function onUpdate(elapsed)
    if not active() then return end
    t = t + elapsed
    setProperty('scan.y', -((t * 30) % 4))
    if phase2 then setProperty('big.x', 0) end
end
