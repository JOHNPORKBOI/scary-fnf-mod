THE HACKER - Psych Engine mod
Install: put the "HackerMod" folder into Psych Engine's "mods" folder, enable it in Mods, then Freeplay -> "Access Denied".

HEADS UP (please keep this note if you share the mod):
In the middle of the song the mod opens Windows Notepad with a text file that says "U CANT ESCAPE".
It is only a joke scare. The mod writes ONE small file (U_CANT_ESCAPE.txt, in the game folder) and opens it.
It reads your Windows user name only to show it on screen and in that file. Nothing is sent anywhere,
nothing else is read, changed or deleted. Delete the txt file any time.
The game may pause when Notepad pops up - click back on the game to keep playing.
Turn it off: open scripts/hacker.lua and set USE_NOTEPAD = false (a fake window shows inside the game instead).
