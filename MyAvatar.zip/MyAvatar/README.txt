MY AVATAR - Psych Engine mod
Install: put the "MyAvatar" folder into Psych Engine's "mods" folder, enable it in Mods, then Freeplay -> "Blocky Beats".
- My Roblox avatar as an FNF opponent with animations
- His voice sings the actual melody notes
- Halfway through: the lights go out, he laughs, then RAGE MODE:
  glowing eye with flame trail, black void, blue arrows, sparks, teleport flickers, screen shakes, health drain
