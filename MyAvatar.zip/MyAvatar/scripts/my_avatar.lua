-- MY AVATAR: voice that follows the melody + RAGE MODE with a glowing eye
local voiceMap = {
    [6400] = 'v_57_s_ya',
    [6600] = 'v_60_s_da',
    [6700] = 'v_62_s_yo',
    [6800] = 'v_64_s_ba',
    [7000] = 'v_62_s_hey',
    [7200] = 'v_60_s_uh',
    [7300] = 'v_62_s_wa',
    [7400] = 'v_64_s_bop',
    [7600] = 'v_67_l_yeah',
    [7900] = 'v_64_s_ski',
    [8000] = 'v_57_s_go',
    [8200] = 'v_60_s_ya',
    [8300] = 'v_62_s_da',
    [8400] = 'v_64_s_yo',
    [8600] = 'v_62_s_ba',
    [8800] = 'v_60_s_hey',
    [8900] = 'v_62_s_uh',
    [9000] = 'v_64_s_wa',
    [9200] = 'v_67_l_bop',
    [9500] = 'v_64_s_yeah',
    [12800] = 'v_69_s_ski',
    [12900] = 'v_67_s_go',
    [13000] = 'v_64_s_ya',
    [13200] = 'v_67_s_da',
    [13300] = 'v_64_s_yo',
    [13400] = 'v_62_s_ba',
    [13600] = 'v_60_s_hey',
    [13800] = 'v_62_s_uh',
    [13900] = 'v_60_s_wa',
    [14000] = 'v_57_l_bop',
    [14400] = 'v_69_s_yeah',
    [14500] = 'v_67_s_ski',
    [14600] = 'v_64_s_go',
    [14800] = 'v_67_s_ya',
    [14900] = 'v_64_s_da',
    [15000] = 'v_62_s_yo',
    [15200] = 'v_60_s_ba',
    [15400] = 'v_62_s_hey',
    [15500] = 'v_60_s_uh',
    [15600] = 'v_57_l_wa',
    [19200] = 'v_57_s_bop',
    [19400] = 'v_60_s_yeah',
    [19500] = 'v_62_s_ski',
    [19600] = 'v_64_s_go',
    [19800] = 'v_62_s_ya',
    [20000] = 'v_60_s_da',
    [20100] = 'v_62_s_yo',
    [20200] = 'v_64_s_ba',
    [20400] = 'v_67_l_hey',
    [20700] = 'v_64_s_uh',
    [20800] = 'v_57_s_wa',
    [21000] = 'v_60_s_bop',
    [21100] = 'v_62_s_yeah',
    [21200] = 'v_64_s_ski',
    [21400] = 'v_62_s_go',
    [21600] = 'v_60_s_ya',
    [21700] = 'v_62_s_da',
    [21800] = 'v_64_s_yo',
    [22000] = 'v_67_l_ba',
    [22300] = 'v_64_s_hey',
    [25600] = 'v_64_s_uh',
    [25700] = 'v_64_s_wa',
    [25800] = 'v_67_s_bop',
    [25900] = 'v_64_s_yeah',
    [26000] = 'v_69_s_ski',
    [26200] = 'v_67_s_go',
    [26300] = 'v_64_s_ya',
    [26400] = 'v_62_s_da',
    [26600] = 'v_60_s_yo',
    [26700] = 'v_62_s_ba',
    [26800] = 'v_64_l_hey',
    [27100] = 'v_60_s_uh',
    [27200] = 'v_64_s_wa',
    [27300] = 'v_64_s_bop',
    [27400] = 'v_67_s_yeah',
    [27500] = 'v_64_s_ski',
    [27600] = 'v_69_s_go',
    [27800] = 'v_67_s_ya',
    [27900] = 'v_64_s_da',
    [28000] = 'v_62_s_yo',
    [28200] = 'v_60_s_ba',
    [28300] = 'v_62_s_hey',
    [28400] = 'v_64_l_uh',
    [28700] = 'v_60_s_wa'
}
local rageMap = {
    [35200] = 'r_57_s_bop',
    [35300] = 'r_57_s_yeah',
    [35400] = 'r_69_s_ski',
    [35500] = 'r_57_s_go',
    [35600] = 'r_67_s_ya',
    [35700] = 'r_65_s_da',
    [35800] = 'r_64_s_yo',
    [36000] = 'r_57_s_ba',
    [36100] = 'r_58_s_hey',
    [36200] = 'r_60_s_uh',
    [36300] = 'r_58_s_wa',
    [36400] = 'r_64_s_bop',
    [36600] = 'r_65_s_yeah',
    [36700] = 'r_64_s_ski',
    [36800] = 'r_57_s_go',
    [36900] = 'r_57_s_ya',
    [37000] = 'r_69_s_da',
    [37100] = 'r_57_s_yo',
    [37200] = 'r_67_s_ba',
    [37300] = 'r_65_s_hey',
    [37400] = 'r_64_s_uh',
    [37600] = 'r_57_s_wa',
    [37700] = 'r_58_s_bop',
    [37800] = 'r_60_s_yeah',
    [37900] = 'r_58_s_ski',
    [38000] = 'r_64_s_go',
    [38200] = 'r_65_s_ya',
    [38300] = 'r_64_s_da',
    [41600] = 'r_69_s_yo',
    [41800] = 'r_67_s_ba',
    [41900] = 'r_65_s_hey',
    [42000] = 'r_64_s_uh',
    [42200] = 'r_65_s_wa',
    [42300] = 'r_64_s_bop',
    [42400] = 'r_62_s_yeah',
    [42500] = 'r_60_s_ski',
    [42600] = 'r_58_s_go',
    [42800] = 'r_57_s_ya',
    [42900] = 'r_58_s_da',
    [43000] = 'r_60_s_yo',
    [43100] = 'r_64_s_ba',
    [43200] = 'r_69_s_hey',
    [43400] = 'r_67_s_uh',
    [43500] = 'r_65_s_wa',
    [43600] = 'r_64_s_bop',
    [43800] = 'r_65_s_yeah',
    [43900] = 'r_64_s_ski',
    [44000] = 'r_62_s_go',
    [44100] = 'r_60_s_ya',
    [44200] = 'r_58_s_da',
    [44400] = 'r_57_s_yo',
    [44500] = 'r_58_s_ba',
    [44600] = 'r_60_s_hey',
    [44700] = 'r_64_s_uh',
    [48000] = 'r_57_s_wa',
    [48100] = 'r_57_s_bop',
    [48200] = 'r_69_s_yeah',
    [48300] = 'r_57_s_ski',
    [48400] = 'r_67_s_go',
    [48500] = 'r_65_s_ya',
    [48600] = 'r_64_s_da',
    [48800] = 'r_57_s_yo',
    [48900] = 'r_58_s_ba',
    [49000] = 'r_60_s_hey',
    [49100] = 'r_58_s_uh',
    [49200] = 'r_64_s_wa',
    [49400] = 'r_65_s_bop',
    [49500] = 'r_64_s_yeah',
    [49600] = 'r_57_s_ski',
    [49700] = 'r_57_s_go',
    [49800] = 'r_69_s_ya',
    [49900] = 'r_57_s_da',
    [50000] = 'r_67_s_yo',
    [50100] = 'r_65_s_ba',
    [50200] = 'r_64_s_hey',
    [50400] = 'r_57_s_uh',
    [50500] = 'r_58_s_wa',
    [50600] = 'r_60_s_bop',
    [50700] = 'r_58_s_yeah',
    [50800] = 'r_64_s_ski',
    [51000] = 'r_65_s_go',
    [51100] = 'r_64_s_ya',
    [54400] = 'r_69_s_da',
    [54600] = 'r_67_s_yo',
    [54700] = 'r_65_s_ba',
    [54800] = 'r_64_s_hey',
    [55000] = 'r_65_s_uh',
    [55100] = 'r_64_s_wa',
    [55200] = 'r_62_s_bop',
    [55300] = 'r_60_s_yeah',
    [55400] = 'r_58_s_ski',
    [55600] = 'r_57_s_go',
    [55700] = 'r_58_s_ya',
    [55800] = 'r_60_s_da',
    [55900] = 'r_64_s_yo',
    [56000] = 'r_69_s_ba',
    [56200] = 'r_67_s_hey',
    [56300] = 'r_65_s_uh',
    [56400] = 'r_64_s_wa',
    [56600] = 'r_65_s_bop',
    [56700] = 'r_64_s_yeah',
    [56800] = 'r_62_s_ski',
    [56900] = 'r_60_s_go',
    [57000] = 'r_58_s_ya',
    [57200] = 'r_57_s_da',
    [57300] = 'r_58_s_yo',
    [57400] = 'r_60_s_ba',
    [57500] = 'r_64_s_hey',
    [60800] = 'r_57_s_uh',
    [61000] = 'r_67_s_wa',
    [61200] = 'r_65_s_bop',
    [61400] = 'r_64_s_yeah',
    [61500] = 'r_69_s_ski',
    [61600] = 'r_62_s_go',
    [61800] = 'r_60_s_ya',
    [62000] = 'r_58_s_da',
    [62100] = 'r_60_s_yo',
    [62200] = 'r_64_s_ba',
    [62300] = 'r_69_s_hey',
    [62400] = 'r_57_s_uh',
    [62600] = 'r_67_s_wa',
    [62800] = 'r_65_s_bop',
    [63000] = 'r_64_s_yeah',
    [63100] = 'r_69_s_ski',
    [63200] = 'r_62_s_go',
    [63400] = 'r_60_s_ya',
    [63600] = 'r_58_s_da',
    [63700] = 'r_60_s_yo',
    [63800] = 'r_64_s_ba',
    [63900] = 'r_69_s_hey'
}
local EYE = {
    idle = {351, 344},
    singLEFT = {263, 345},
    singDOWN = {357, 392},
    singUP = {352, 309},
    singRIGHT = {440, 344}
}
local dirs = {'left', 'down', 'up', 'right'}
local RAGE_STEP = 352
local raging = false
local emberN = 0
local t = 0

local function active() return dadName == 'my-avatar' or dadName == 'my-avatar-rage' end

function onCreate()
    addCharacterToList('my-avatar-rage', 'dad')
    precacheImage('rage/glow'); precacheImage('rage/ember'); precacheImage('rage/vignette')
    for _, s in ipairs({'rage_ignite', 'rage_laugh', 'rage_blink', 'rage_hit'}) do precacheSound(s) end
end

function onCreatePost()
    if not active() then return end
    makeLuaSprite('void', '', -3000, -2500)
    makeGraphic('void', 9000, 7000, '000000')
    setProperty('void.alpha', 0)
    addLuaSprite('void', false)

    makeLuaSprite('eyeGlow', 'rage/glow', 0, 0)
    setBlendMode('eyeGlow', 'add')
    setProperty('eyeGlow.alpha', 0)
    addLuaSprite('eyeGlow', true)

    makeLuaSprite('vig', 'rage/vignette', 0, 0)
    setObjectCamera('vig', 'hud')
    setProperty('vig.alpha', 0)
    addLuaSprite('vig', true)

    makeLuaSprite('flash', '', 0, 0)
    makeGraphic('flash', screenWidth, screenHeight, 'FFFFFF')
    setObjectCamera('flash', 'other')
    setProperty('flash.alpha', 0)
    addLuaSprite('flash', true)
end

local function spawnEmber(x, y)
    emberN = emberN + 1
    local tag = 'ember' .. emberN
    makeLuaSprite(tag, 'rage/ember', x - 24 + getRandomInt(-20, 20), y - 24 + getRandomInt(-15, 15))
    setBlendMode(tag, 'add')
    addLuaSprite(tag, true)
    local s = getRandomFloat(0.6, 1.6)
    scaleObject(tag, s, s)
    doTweenY(tag .. 'Y', tag, getProperty(tag .. '.y') - getRandomInt(120, 260), getRandomFloat(0.6, 1.0), 'quadOut')
    doTweenX(tag .. 'X', tag, getProperty(tag .. '.x') - getRandomInt(30, 140), getRandomFloat(0.6, 1.0), 'sineOut')
    doTweenAlpha(tag .. 'A', tag, 0, 1.1, 'linear')
end

local function eyePos()
    local anim = getProperty('dad.animation.curAnim.name') or 'idle'
    local e = EYE[anim] or EYE.idle
    return getProperty('dad.x') + e[1], getProperty('dad.y') + e[2]
end

function onTweenCompleted(tag)
    if string.sub(tag, 1, 5) == 'ember' and string.sub(tag, -1) == 'A' then
        removeLuaSprite(string.sub(tag, 1, -2), true)
    end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    if not active() or isSustainNote then return end
    local key = math.floor(getPropertyFromGroup('notes', id, 'strumTime') + 0.5)
    local snd = raging and rageMap[key] or voiceMap[key]
    if snd == nil then snd = (raging and 'rage_' or 'avatar_') .. dirs[direction + 1] end
    playSound(snd, 1)
    if raging then
        local x, y = eyePos()
        spawnEmber(x, y)
        cameraShake('game', 0.006, 0.12)
        cameraShake('hud', 0.003, 0.1)
        if getProperty('health') > 0.35 then setProperty('health', getProperty('health') - 0.018) end
        setProperty('eyeGlow.alpha', 1)
    end
end

function onStepHit()
    if not active() then return end
    if curStep == RAGE_STEP - 32 then
        -- music drops: lights go out, camera on him
        doTweenAlpha('voidIn', 'void', 0.75, 2.4, 'quadInOut')
        doTweenAlpha('gfOut', 'gf', 0, 2.0, 'quadOut')
        doTweenAlpha('hudDim', 'camHUD', 0.35, 1.5, 'quadOut')
        setProperty('defaultCamZoom', 0.95)
        cameraFlash('game', '000000', 0.4, false)
    elseif curStep == RAGE_STEP - 28 then
        playSound('rage_laugh', 1)
    elseif curStep == RAGE_STEP - 16 or curStep == RAGE_STEP - 8 then
        cameraShake('game', 0.004, 0.3)
    elseif curStep == RAGE_STEP then
        raging = true
        triggerEvent('Change Character', 'dad', 'my-avatar-rage')
        playSound('rage_ignite', 1)
        setProperty('void.alpha', 1)
        setProperty('flash.color', getColorFromHex('00E5FF'))
        setProperty('flash.alpha', 0.9)
        doTweenAlpha('flashOut', 'flash', 0, 0.8, 'quadOut')
        doTweenAlpha('hudBack', 'camHUD', 1, 0.4, 'quadOut')
        doTweenAlpha('vigIn', 'vig', 1, 0.6, 'quadOut')
        cameraShake('game', 0.03, 0.9)
        cameraShake('hud', 0.015, 0.9)
        setProperty('defaultCamZoom', 0.8)
        setProperty('eyeGlow.alpha', 1)
        for i = 0, 3 do
            setPropertyFromGroup('opponentStrums', i, 'color', getColorFromHex('00E5FF'))
        end
        setHealthBarColors('00E5FF', '31B0D1')
    end
end

function onBeatHit()
    if not raging then return end
    -- every 8 beats he blinks out and back (teleport flicker)
    if curBeat % 8 == 4 then
        playSound('rage_blink', 0.7)
        setProperty('dad.alpha', 0)
        setProperty('eyeGlow.alpha', 0)
        runTimer('blinkBack', 0.09)
    end
    if curBeat % 16 == 0 then
        playSound('rage_hit', 0.8)
        cameraShake('game', 0.012, 0.25)
        setProperty('flash.color', getColorFromHex('00E5FF'))
        setProperty('flash.alpha', 0.25)
        doTweenAlpha('flashOut', 'flash', 0, 0.35, 'quadOut')
    end
end

function onTimerCompleted(tag)
    if tag == 'blinkBack' then
        setProperty('dad.alpha', 1)
        setProperty('eyeGlow.alpha', 1)
        cameraShake('game', 0.008, 0.15)
    end
end

function onUpdate(elapsed)
    if not raging then return end
    t = t + elapsed
    local x, y = eyePos()
    local pulse = 1 + 0.18 * math.sin(t * 9) + 0.08 * math.sin(t * 23)
    scaleObject('eyeGlow', 0.75 * pulse, 0.75 * pulse)
    setProperty('eyeGlow.x', x - getProperty('eyeGlow.width') / 2)
    setProperty('eyeGlow.y', y - getProperty('eyeGlow.height') / 2)
    local a = getProperty('eyeGlow.alpha')
    if a > 0.75 then setProperty('eyeGlow.alpha', a - elapsed * 0.6) end
    setProperty('vig.alpha', 0.75 + 0.25 * math.sin(t * 3))
end
