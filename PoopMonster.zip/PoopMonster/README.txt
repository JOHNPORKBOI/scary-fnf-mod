POOP MONSTER - Psych Engine mod
1. Copy the "PoopMonster" folder into your Psych Engine "mods" folder.
2. Start the game -> Mods menu -> make sure Poop Monster is enabled.
3. Freeplay -> "Stinky".
The poop monster farts on every note, big fart + screen shake every 16 beats.
You can also pick "poop-monster" as opponent in any chart (Chart Editor).
