-- Poop Monster: farts on every note he sings
local farts = {'fart1', 'fart2', 'fart3', 'fart4'}

function onCreatePost()
    if dadName == 'poop-monster' then
        -- green stink tint on the whole stage
        makeLuaSprite('stink', '', -800, -600)
        makeGraphic('stink', 3000, 2000, '6BBF3A')
        setScrollFactor('stink', 0, 0)
        setProperty('stink.alpha', 0)
        addLuaSprite('stink', true)
    end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    if dadName ~= 'poop-monster' or isSustainNote then return end
    playSound(farts[getRandomInt(1, #farts)], 0.9)
    cancelTween('stinkFade')
    setProperty('stink.alpha', 0.18)
    doTweenAlpha('stinkFade', 'stink', 0, 0.4, 'quadOut')
end

function onBeatHit()
    -- every 16 beats: BIG fart + camera shake
    if dadName == 'poop-monster' and curBeat > 0 and curBeat % 16 == 0 then
        playSound('bigfart', 1)
        cameraShake('game', 0.015, 0.6)
        cancelTween('stinkFade')
        setProperty('stink.alpha', 0.4)
        doTweenAlpha('stinkFade', 'stink', 0, 1.2, 'quadOut')
    end
end

-- player misses get a little "pfft" too
function noteMiss(id, direction, noteType, isSustainNote)
    if dadName == 'poop-monster' then playSound('fart4', 0.5) end
end
