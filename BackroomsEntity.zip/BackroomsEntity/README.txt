BACKROOMS: LIFELESS - Psych Engine mod
Install: put the "BackroomsEntity" folder into Psych Engine's "mods" folder, enable it in the Mods menu,
then Freeplay -> "Level 0".
- Lifeless: tall many-eyed entity with long arms, glitchy animations
- Distorted demonic rap voice (different sound per arrow)
- Level 0 stage, flickering lights, health drain, scream + blackout every 32 beats
If he stands too high/low: Character Editor -> "lifeless" -> change position.
