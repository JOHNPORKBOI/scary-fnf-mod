function onCreate()
    makeLuaSprite('level0', 'backrooms/level0', -1100, -620)
    setScrollFactor('level0', 0.95, 0.95)
    addLuaSprite('level0', false)
    precacheSound('hum')
end
