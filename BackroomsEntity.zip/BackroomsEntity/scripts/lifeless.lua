-- Lifeless: distorted rap voice, flickering lights, glitches
local dirs = {'left', 'down', 'up', 'right'}

function onCreatePost()
    if dadName ~= 'lifeless' then return end
    makeLuaSprite('dark', '', 0, 0)
    makeGraphic('dark', screenWidth, screenHeight, '000000')
    setObjectCamera('dark', 'other')
    setProperty('dark.alpha', 0)
    addLuaSprite('dark', true)
    makeLuaSprite('flash', '', 0, 0)
    makeGraphic('flash', screenWidth, screenHeight, 'FFFFFF')
    setObjectCamera('flash', 'other')
    setProperty('flash.alpha', 0)
    addLuaSprite('flash', true)
    for _, d in ipairs(dirs) do
        precacheSound('lifeless_'..d..'1'); precacheSound('lifeless_'..d..'2')
    end
    precacheSound('lifeless_scream'); precacheSound('glitch'); precacheSound('flicker')
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    if dadName ~= 'lifeless' or isSustainNote then return end
    playSound('lifeless_'..dirs[direction + 1]..getRandomInt(1, 2), 0.85)
    -- he drains your health (never kills you)
    if getProperty('health') > 0.3 then
        setProperty('health', getProperty('health') - 0.015)
    end
    setProperty('camGame.zoom', getProperty('camGame.zoom') + 0.012)
    if getRandomBool(12) then
        cameraShake('game', 0.006, 0.15)
        setProperty('iconP2.angle', getRandomInt(-15, 15))
    end
end

local function flicker(strength)
    playSound('flicker', 0.5)
    cancelTween('darkFade')
    setProperty('dark.alpha', strength)
    doTweenAlpha('darkFade', 'dark', 0, getRandomFloat(0.15, 0.4), 'linear')
end

function onBeatHit()
    if dadName ~= 'lifeless' then return end
    if getRandomBool(10) then flicker(getRandomFloat(0.5, 0.95)) end
    -- every 32 beats: lights die, scream, glitch
    if curBeat > 0 and curBeat % 32 == 0 then
        setProperty('dark.alpha', 1)
        runTimer('screamTime', 0.25)
    end
end

function onTimerCompleted(tag)
    if tag == 'screamTime' then
        playSound('lifeless_scream', 1)
        playSound('glitch', 0.8)
        setProperty('dark.alpha', 0)
        setProperty('flash.alpha', 0.6)
        doTweenAlpha('flashFade', 'flash', 0, 0.5, 'quadOut')
        cameraShake('game', 0.025, 0.8)
        cameraShake('hud', 0.012, 0.8)
        triggerEvent('Play Animation', 'singUP', 'dad')
    end
end

function noteMiss(id, direction, noteType, isSustainNote)
    if dadName == 'lifeless' and getRandomBool(30) then
        playSound('glitch', 0.4)
        cameraShake('hud', 0.008, 0.2)
    end
end
