MY AVATAR - Psych Engine mod
Install: put the "MyAvatar" folder into Psych Engine's "mods" folder, enable it in Mods, then Freeplay -> "Blocky Beats".
Easy / Normal / Hard. Both singers have voices that follow the melody.
Halfway: stutter drop, lights out, laugh -> RAGE MODE (glowing eye, black void, swaying arrows, eye blasts, teleports).
