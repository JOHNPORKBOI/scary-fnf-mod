function onCreate()
    makeLuaSprite('baseplate', 'baseplate/baseplate', -1000, -480)
    setScrollFactor('baseplate', 0.95, 0.95)
    addLuaSprite('baseplate', false)
end
