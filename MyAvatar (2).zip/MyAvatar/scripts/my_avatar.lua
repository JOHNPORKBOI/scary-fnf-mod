-- MY AVATAR: both singers have voices that follow the melody + RAGE MODE
local voiceMap = {
    [2909] = 'v_57_s_yo',
    [3091] = 'v_57_s_ba',
    [3182] = 'v_60_s_wa',
    [3273] = 'v_62_s_ski',
    [3455] = 'v_64_s_da',
    [3545] = 'v_62_s_go',
    [3636] = 'v_60_s_ski',
    [3818] = 'v_57_s_bop',
    [3909] = 'v_60_s_go',
    [4000] = 'v_62_s_yo',
    [4091] = 'v_63_s_ba',
    [4182] = 'v_64_s_uh',
    [4364] = 'v_57_s_yo',
    [4545] = 'v_57_s_ba',
    [4636] = 'v_60_s_wa',
    [4727] = 'v_62_s_ski',
    [4909] = 'v_64_s_da',
    [5000] = 'v_62_s_go',
    [5091] = 'v_60_s_ski',
    [5273] = 'v_57_s_bop',
    [5364] = 'v_60_s_go',
    [5455] = 'v_62_s_yo',
    [5545] = 'v_63_s_ba',
    [5636] = 'v_64_s_uh',
    [8727] = 'v_69_s_ba',
    [8818] = 'v_67_s_da',
    [8909] = 'v_64_s_go',
    [9000] = 'v_67_s_yo',
    [9091] = 'v_69_s_uh',
    [9273] = 'v_67_s_hey',
    [9364] = 'v_64_s_da',
    [9455] = 'v_62_s_ya',
    [9545] = 'v_64_s_yo',
    [9636] = 'v_60_s_go',
    [9818] = 'v_57_s_yeah',
    [9909] = 'v_60_s_ya',
    [10000] = 'v_62_s_ba',
    [10091] = 'v_64_s_uh',
    [10182] = 'v_69_s_ba',
    [10273] = 'v_67_s_da',
    [10364] = 'v_64_s_go',
    [10455] = 'v_67_s_yo',
    [10545] = 'v_69_s_uh',
    [10727] = 'v_67_s_hey',
    [10818] = 'v_64_s_da',
    [10909] = 'v_62_s_ya',
    [11000] = 'v_64_s_yo',
    [11091] = 'v_60_s_go',
    [11273] = 'v_57_s_yeah',
    [11364] = 'v_60_s_ya',
    [11455] = 'v_62_s_ba',
    [11545] = 'v_64_s_uh',
    [14545] = 'v_64_s_ski',
    [14636] = 'v_64_s_ski',
    [14727] = 'v_67_s_yo',
    [14818] = 'v_69_s_hey',
    [14909] = 'v_67_s_ba',
    [15000] = 'v_64_s_ya',
    [15091] = 'v_62_s_go',
    [15182] = 'v_60_s_yeah',
    [15273] = 'v_62_s_ya',
    [15455] = 'v_64_s_ba',
    [15545] = 'v_67_s_wa',
    [15636] = 'v_69_l_ski',
    [15909] = 'v_67_s_yeah',
    [16000] = 'v_64_s_ski',
    [16091] = 'v_64_s_ski',
    [16182] = 'v_67_s_yo',
    [16273] = 'v_69_s_hey',
    [16364] = 'v_67_s_ba',
    [16455] = 'v_64_s_ya',
    [16545] = 'v_62_s_go',
    [16636] = 'v_60_s_yeah',
    [16727] = 'v_62_s_ya',
    [16909] = 'v_64_s_ba',
    [17000] = 'v_67_s_wa',
    [17091] = 'v_69_l_ski',
    [17364] = 'v_67_s_yeah'
}
local rageMap = {
    [23273] = 'r_57_s_yo',
    [23364] = 'r_57_s_yo',
    [23455] = 'r_69_s_hey',
    [23545] = 'r_57_s_ba',
    [23636] = 'r_67_s_ba',
    [23727] = 'r_57_s_hey',
    [23818] = 'r_65_s_yo',
    [23909] = 'r_64_s_da',
    [24000] = 'r_57_s_wa',
    [24091] = 'r_58_s_bop',
    [24182] = 'r_60_s_go',
    [24273] = 'r_58_s_yeah',
    [24364] = 'r_64_s_hey',
    [24455] = 'r_65_s_uh',
    [24545] = 'r_67_s_yeah',
    [24636] = 'r_69_s_go',
    [24727] = 'r_57_s_yo',
    [24818] = 'r_57_s_yo',
    [24909] = 'r_69_s_hey',
    [25000] = 'r_57_s_ba',
    [25091] = 'r_67_s_ba',
    [25182] = 'r_57_s_hey',
    [25273] = 'r_65_s_yo',
    [25364] = 'r_64_s_da',
    [25455] = 'r_57_s_wa',
    [25545] = 'r_58_s_bop',
    [25636] = 'r_60_s_go',
    [25727] = 'r_58_s_yeah',
    [25818] = 'r_64_s_hey',
    [25909] = 'r_65_s_uh',
    [26000] = 'r_67_s_yeah',
    [26091] = 'r_69_s_go',
    [29091] = 'r_69_s_ba',
    [29273] = 'r_67_s_yo',
    [29364] = 'r_65_s_ya',
    [29455] = 'r_64_s_ya',
    [29545] = 'r_65_s_da',
    [29636] = 'r_64_s_da',
    [29727] = 'r_62_s_go',
    [29818] = 'r_60_s_ski',
    [29909] = 'r_58_s_bop',
    [30000] = 'r_57_s_bop',
    [30091] = 'r_58_s_yeah',
    [30182] = 'r_60_s_ya',
    [30273] = 'r_64_s_hey',
    [30364] = 'r_65_s_wa',
    [30455] = 'r_69_s_go',
    [30545] = 'r_69_s_ba',
    [30727] = 'r_67_s_yo',
    [30818] = 'r_65_s_ya',
    [30909] = 'r_64_s_ya',
    [31000] = 'r_65_s_da',
    [31091] = 'r_64_s_da',
    [31182] = 'r_62_s_go',
    [31273] = 'r_60_s_ski',
    [31364] = 'r_58_s_bop',
    [31455] = 'r_57_s_bop',
    [31545] = 'r_58_s_yeah',
    [31636] = 'r_60_s_ya',
    [31727] = 'r_64_s_hey',
    [31818] = 'r_65_s_wa',
    [31909] = 'r_69_s_go',
    [34909] = 'r_70_s_hey',
    [35000] = 'r_69_s_ba',
    [35091] = 'r_67_s_yo',
    [35182] = 'r_69_s_hey',
    [35273] = 'r_65_s_da',
    [35364] = 'r_69_s_uh',
    [35455] = 'r_64_s_da',
    [35545] = 'r_69_s_wa',
    [35636] = 'r_70_l_yeah',
    [35909] = 'r_69_s_yeah',
    [36000] = 'r_67_s_bop',
    [36091] = 'r_65_s_uh',
    [36182] = 'r_64_s_uh',
    [36273] = 'r_58_s_go',
    [36364] = 'r_70_s_hey',
    [36455] = 'r_69_s_ba',
    [36545] = 'r_67_s_yo',
    [36636] = 'r_69_s_hey',
    [36727] = 'r_65_s_da',
    [36818] = 'r_69_s_uh',
    [36909] = 'r_64_s_da',
    [37000] = 'r_69_s_wa',
    [37091] = 'r_70_l_yeah',
    [37364] = 'r_69_s_yeah',
    [37455] = 'r_67_s_bop',
    [37545] = 'r_65_s_uh',
    [37636] = 'r_64_s_uh',
    [37727] = 'r_58_s_go',
    [40727] = 'r_69_s_ba',
    [40909] = 'r_67_s_yo',
    [41000] = 'r_65_s_ya',
    [41091] = 'r_64_s_ya',
    [41182] = 'r_65_s_da',
    [41273] = 'r_64_s_da',
    [41364] = 'r_62_s_go',
    [41455] = 'r_60_s_ski',
    [41545] = 'r_58_s_bop',
    [41636] = 'r_57_s_bop',
    [41727] = 'r_58_s_yeah',
    [41818] = 'r_60_s_ya',
    [41909] = 'r_64_s_hey',
    [42000] = 'r_65_s_wa',
    [42091] = 'r_69_s_go',
    [42182] = 'r_69_s_ba',
    [42364] = 'r_67_s_yo',
    [42455] = 'r_65_s_ya',
    [42545] = 'r_64_s_ya',
    [42636] = 'r_65_s_da',
    [42727] = 'r_64_s_da',
    [42818] = 'r_62_s_go',
    [42909] = 'r_60_s_ski',
    [43000] = 'r_58_s_bop',
    [43091] = 'r_57_s_bop',
    [43182] = 'r_58_s_yeah',
    [43273] = 'r_60_s_ya',
    [43364] = 'r_64_s_hey',
    [43455] = 'r_65_s_wa',
    [43545] = 'r_69_s_go',
    [46545] = 'r_69_s_ba',
    [46636] = 'r_57_s_yo',
    [46727] = 'r_69_s_hey',
    [46818] = 'r_57_s_ba',
    [46909] = 'r_70_s_wa',
    [47000] = 'r_58_s_uh',
    [47091] = 'r_70_s_bop',
    [47182] = 'r_58_s_wa',
    [47273] = 'r_67_s_uh',
    [47364] = 'r_57_s_wa',
    [47455] = 'r_67_s_wa',
    [47545] = 'r_57_s_bop',
    [47636] = 'r_65_s_uh',
    [47727] = 'r_64_s_hey',
    [47818] = 'r_60_s_da',
    [47909] = 'r_58_s_go',
    [48000] = 'r_69_s_ba',
    [48091] = 'r_57_s_yo',
    [48182] = 'r_69_s_hey',
    [48273] = 'r_57_s_ba',
    [48364] = 'r_70_s_wa',
    [48455] = 'r_58_s_uh',
    [48545] = 'r_70_s_bop',
    [48636] = 'r_58_s_wa',
    [48727] = 'r_67_s_uh',
    [48818] = 'r_57_s_wa',
    [48909] = 'r_67_s_wa',
    [49000] = 'r_57_s_bop',
    [49091] = 'r_65_s_uh',
    [49182] = 'r_64_s_hey',
    [49273] = 'r_60_s_da',
    [49364] = 'r_58_s_go',
    [52364] = 'r_69_s_ba',
    [52455] = 'r_57_s_yo',
    [52545] = 'r_69_s_hey',
    [52636] = 'r_57_s_ba',
    [52727] = 'r_70_s_wa',
    [52818] = 'r_58_s_uh',
    [52909] = 'r_70_s_bop',
    [53000] = 'r_58_s_wa',
    [53091] = 'r_67_s_uh',
    [53182] = 'r_57_s_wa',
    [53273] = 'r_67_s_wa',
    [53364] = 'r_57_s_bop',
    [53455] = 'r_65_s_uh',
    [53545] = 'r_64_s_hey',
    [53636] = 'r_60_s_da',
    [53727] = 'r_58_s_go',
    [53818] = 'r_69_s_ba',
    [53909] = 'r_57_s_yo',
    [54000] = 'r_69_s_hey',
    [54091] = 'r_57_s_ba',
    [54182] = 'r_70_s_wa',
    [54273] = 'r_58_s_uh',
    [54364] = 'r_70_s_bop',
    [54455] = 'r_58_s_wa',
    [54545] = 'r_67_s_uh',
    [54636] = 'r_57_s_wa',
    [54727] = 'r_67_s_wa',
    [54818] = 'r_57_s_bop',
    [54909] = 'r_65_s_uh',
    [55000] = 'r_64_s_hey',
    [55091] = 'r_60_s_da',
    [55182] = 'r_58_s_go'
}
local bfMap = {
    [5818] = 'bf_69_s_bop',
    [6000] = 'bf_69_s_ba',
    [6091] = 'bf_72_s_bap',
    [6182] = 'bf_74_s_bop',
    [6364] = 'bf_76_s_bee',
    [6455] = 'bf_74_s_ba',
    [6545] = 'bf_72_s_bop',
    [6727] = 'bf_69_s_da',
    [6818] = 'bf_72_s_ba',
    [6909] = 'bf_74_s_bap',
    [7000] = 'bf_75_s_da',
    [7091] = 'bf_76_s_bop',
    [7273] = 'bf_69_s_bop',
    [7455] = 'bf_69_s_ba',
    [7545] = 'bf_72_s_bap',
    [7636] = 'bf_74_s_bop',
    [7818] = 'bf_76_s_bee',
    [7909] = 'bf_74_s_ba',
    [8000] = 'bf_72_s_bop',
    [8182] = 'bf_69_s_da',
    [8273] = 'bf_72_s_ba',
    [8364] = 'bf_74_s_bap',
    [8455] = 'bf_75_s_da',
    [8545] = 'bf_76_s_bop',
    [11636] = 'bf_81_s_da',
    [11727] = 'bf_79_s_bee',
    [11818] = 'bf_76_s_ba',
    [11909] = 'bf_79_s_bap',
    [12000] = 'bf_81_s_bop',
    [12182] = 'bf_79_s_bep',
    [12273] = 'bf_76_s_bee',
    [12364] = 'bf_74_s_skee',
    [12455] = 'bf_76_s_bap',
    [12545] = 'bf_72_s_ba',
    [12727] = 'bf_69_s_bep',
    [12818] = 'bf_72_s_skee',
    [12909] = 'bf_74_s_da',
    [13000] = 'bf_76_s_bop',
    [13091] = 'bf_81_s_da',
    [13182] = 'bf_79_s_bee',
    [13273] = 'bf_76_s_ba',
    [13364] = 'bf_79_s_bap',
    [13455] = 'bf_81_s_bop',
    [13636] = 'bf_79_s_bep',
    [13727] = 'bf_76_s_bee',
    [13818] = 'bf_74_s_skee',
    [13909] = 'bf_76_s_bap',
    [14000] = 'bf_72_s_ba',
    [14182] = 'bf_69_s_bep',
    [14273] = 'bf_72_s_skee',
    [14364] = 'bf_74_s_da',
    [14455] = 'bf_76_s_bop',
    [17455] = 'bf_76_s_bop',
    [17545] = 'bf_76_s_bop',
    [17636] = 'bf_79_s_bap',
    [17727] = 'bf_81_s_bep',
    [17818] = 'bf_79_s_da',
    [17909] = 'bf_76_s_skee',
    [18000] = 'bf_74_s_ba',
    [18091] = 'bf_72_s_bep',
    [18182] = 'bf_74_s_skee',
    [18364] = 'bf_76_s_da',
    [18455] = 'bf_79_s_ba',
    [18545] = 'bf_81_l_bap',
    [18818] = 'bf_79_s_bee',
    [18909] = 'bf_76_s_bop',
    [19000] = 'bf_76_s_bop',
    [19091] = 'bf_79_s_bap',
    [19182] = 'bf_81_s_bep',
    [19273] = 'bf_79_s_da',
    [19364] = 'bf_76_s_skee',
    [19455] = 'bf_74_s_ba',
    [19545] = 'bf_72_s_bep',
    [19636] = 'bf_74_s_skee',
    [19818] = 'bf_76_s_da',
    [19909] = 'bf_79_s_ba',
    [20000] = 'bf_81_l_bap',
    [20273] = 'bf_79_s_bee',
    [26182] = 'bf_71_s_bop',
    [26273] = 'bf_71_s_bop',
    [26364] = 'bf_83_s_bep',
    [26455] = 'bf_71_s_ba',
    [26545] = 'bf_81_s_da',
    [26636] = 'bf_71_s_skee',
    [26727] = 'bf_79_s_bap',
    [26818] = 'bf_78_s_bee',
    [26909] = 'bf_71_s_bap',
    [27000] = 'bf_72_s_da',
    [27091] = 'bf_74_s_ba',
    [27182] = 'bf_72_s_bep',
    [27273] = 'bf_78_s_bep',
    [27364] = 'bf_79_s_bop',
    [27455] = 'bf_81_s_bee',
    [27545] = 'bf_83_s_da',
    [27636] = 'bf_71_s_bop',
    [27727] = 'bf_71_s_bop',
    [27818] = 'bf_83_s_bep',
    [27909] = 'bf_71_s_ba',
    [28000] = 'bf_81_s_da',
    [28091] = 'bf_71_s_skee',
    [28182] = 'bf_79_s_bap',
    [28273] = 'bf_78_s_bee',
    [28364] = 'bf_71_s_bap',
    [28455] = 'bf_72_s_da',
    [28545] = 'bf_74_s_ba',
    [28636] = 'bf_72_s_bep',
    [28727] = 'bf_78_s_bep',
    [28818] = 'bf_79_s_bop',
    [28909] = 'bf_81_s_bee',
    [29000] = 'bf_83_s_da',
    [32000] = 'bf_83_s_da',
    [32182] = 'bf_81_s_bap',
    [32273] = 'bf_79_s_skee',
    [32364] = 'bf_78_s_skee',
    [32455] = 'bf_79_s_bee',
    [32545] = 'bf_78_s_bee',
    [32636] = 'bf_76_s_ba',
    [32727] = 'bf_74_s_bop',
    [32818] = 'bf_72_s_da',
    [32909] = 'bf_71_s_da',
    [33000] = 'bf_72_s_bep',
    [33091] = 'bf_74_s_skee',
    [33182] = 'bf_78_s_bep',
    [33273] = 'bf_79_s_ba',
    [33364] = 'bf_83_s_da',
    [33455] = 'bf_83_s_da',
    [33636] = 'bf_81_s_bap',
    [33727] = 'bf_79_s_skee',
    [33818] = 'bf_78_s_skee',
    [33909] = 'bf_79_s_bee',
    [34000] = 'bf_78_s_bee',
    [34091] = 'bf_76_s_ba',
    [34182] = 'bf_74_s_bop',
    [34273] = 'bf_72_s_da',
    [34364] = 'bf_71_s_da',
    [34455] = 'bf_72_s_bep',
    [34545] = 'bf_74_s_skee',
    [34636] = 'bf_78_s_bep',
    [34727] = 'bf_79_s_ba',
    [34818] = 'bf_83_s_da',
    [37818] = 'bf_84_s_bep',
    [37909] = 'bf_83_s_da',
    [38000] = 'bf_81_s_bap',
    [38091] = 'bf_83_s_bep',
    [38182] = 'bf_79_s_bee',
    [38273] = 'bf_83_s_bop',
    [38364] = 'bf_78_s_bee',
    [38455] = 'bf_83_s_ba',
    [38545] = 'bf_84_l_bee',
    [38818] = 'bf_83_s_bee',
    [38909] = 'bf_81_s_skee',
    [39000] = 'bf_79_s_bop',
    [39091] = 'bf_78_s_bop',
    [39182] = 'bf_72_s_ba',
    [39273] = 'bf_84_s_bep',
    [39364] = 'bf_83_s_da',
    [39455] = 'bf_81_s_bap',
    [39545] = 'bf_83_s_bep',
    [39636] = 'bf_79_s_bee',
    [39727] = 'bf_83_s_bop',
    [39818] = 'bf_78_s_bee',
    [39909] = 'bf_83_s_ba',
    [40000] = 'bf_84_l_bee',
    [40273] = 'bf_83_s_bee',
    [40364] = 'bf_81_s_skee',
    [40455] = 'bf_79_s_bop',
    [40545] = 'bf_78_s_bop',
    [40636] = 'bf_72_s_ba',
    [43636] = 'bf_83_s_da',
    [43818] = 'bf_81_s_bap',
    [43909] = 'bf_79_s_skee',
    [44000] = 'bf_78_s_skee',
    [44091] = 'bf_79_s_bee',
    [44182] = 'bf_78_s_bee',
    [44273] = 'bf_76_s_ba',
    [44364] = 'bf_74_s_bop',
    [44455] = 'bf_72_s_da',
    [44545] = 'bf_71_s_da',
    [44636] = 'bf_72_s_bep',
    [44727] = 'bf_74_s_skee',
    [44818] = 'bf_78_s_bep',
    [44909] = 'bf_79_s_ba',
    [45000] = 'bf_83_s_da',
    [45091] = 'bf_83_s_da',
    [45273] = 'bf_81_s_bap',
    [45364] = 'bf_79_s_skee',
    [45455] = 'bf_78_s_skee',
    [45545] = 'bf_79_s_bee',
    [45636] = 'bf_78_s_bee',
    [45727] = 'bf_76_s_ba',
    [45818] = 'bf_74_s_bop',
    [45909] = 'bf_72_s_da',
    [46000] = 'bf_71_s_da',
    [46091] = 'bf_72_s_bep',
    [46182] = 'bf_74_s_skee',
    [46273] = 'bf_78_s_bep',
    [46364] = 'bf_79_s_ba',
    [46455] = 'bf_83_s_da',
    [49455] = 'bf_83_s_da',
    [49545] = 'bf_71_s_bop',
    [49636] = 'bf_83_s_bep',
    [49727] = 'bf_71_s_ba',
    [49818] = 'bf_84_s_ba',
    [49909] = 'bf_72_s_bee',
    [50000] = 'bf_84_s_skee',
    [50091] = 'bf_72_s_bap',
    [50182] = 'bf_81_s_bop',
    [50273] = 'bf_71_s_bap',
    [50364] = 'bf_81_s_ba',
    [50455] = 'bf_71_s_da',
    [50545] = 'bf_79_s_bop',
    [50636] = 'bf_78_s_bep',
    [50727] = 'bf_74_s_bee',
    [50818] = 'bf_72_s_ba',
    [50909] = 'bf_83_s_da',
    [51000] = 'bf_71_s_bop',
    [51091] = 'bf_83_s_bep',
    [51182] = 'bf_71_s_ba',
    [51273] = 'bf_84_s_ba',
    [51364] = 'bf_72_s_bee',
    [51455] = 'bf_84_s_skee',
    [51545] = 'bf_72_s_bap',
    [51636] = 'bf_81_s_bop',
    [51727] = 'bf_71_s_bap',
    [51818] = 'bf_81_s_ba',
    [51909] = 'bf_71_s_da',
    [52000] = 'bf_79_s_bop',
    [52091] = 'bf_78_s_bep',
    [52182] = 'bf_74_s_bee',
    [52273] = 'bf_72_s_ba',
    [55273] = 'bf_83_s_da',
    [55364] = 'bf_71_s_bop',
    [55455] = 'bf_83_s_bep',
    [55545] = 'bf_71_s_ba',
    [55636] = 'bf_84_s_ba',
    [55727] = 'bf_72_s_bee',
    [55818] = 'bf_84_s_skee',
    [55909] = 'bf_72_s_bap',
    [56000] = 'bf_81_s_bop',
    [56091] = 'bf_71_s_bap',
    [56182] = 'bf_81_s_ba',
    [56273] = 'bf_71_s_da',
    [56364] = 'bf_79_s_bop',
    [56455] = 'bf_78_s_bep',
    [56545] = 'bf_74_s_bee',
    [56636] = 'bf_72_s_ba',
    [56727] = 'bf_83_s_da',
    [56818] = 'bf_71_s_bop',
    [56909] = 'bf_83_s_bep',
    [57000] = 'bf_71_s_ba',
    [57091] = 'bf_84_s_ba',
    [57182] = 'bf_72_s_bee',
    [57273] = 'bf_84_s_skee',
    [57364] = 'bf_72_s_bap',
    [57455] = 'bf_81_s_bop',
    [57545] = 'bf_71_s_bap',
    [57636] = 'bf_81_s_ba',
    [57727] = 'bf_71_s_da',
    [57818] = 'bf_79_s_bop',
    [57909] = 'bf_78_s_bep',
    [58000] = 'bf_74_s_bee',
    [58091] = 'bf_72_s_ba'
}
local EYE = {
    idle = {351, 344},
    singLEFT = {263, 345},
    singDOWN = {357, 392},
    singUP = {352, 309},
    singRIGHT = {440, 344}
}
local dirs = {'left', 'down', 'up', 'right'}
local RAGE_STEP = 256
local DROP_STEP = 224
local END_STEP = 640
local RAGE_BEAT = RAGE_STEP / 4
local raging, ended, charging = false, false, false
local emberN, t, sway = 0, 0, 0
local dadBaseX = 0

local function active() return dadName == 'my-avatar' or dadName == 'my-avatar-rage' end

function onCreate()
    addCharacterToList('my-avatar-rage', 'dad')
    precacheImage('rage/glow'); precacheImage('rage/ember'); precacheImage('rage/vignette')
    for _, s in ipairs({'rage_ignite', 'rage_laugh', 'rage_blink', 'rage_charge', 'rage_blast'}) do precacheSound(s) end
end

function onCreatePost()
    if not active() then return end
    makeLuaSprite('void', '', -3000, -2500)
    makeGraphic('void', 9000, 7000, '000000')
    setProperty('void.alpha', 0)
    addLuaSprite('void', false)

    makeLuaSprite('eyeGlow', 'rage/glow', 0, 0)
    setBlendMode('eyeGlow', 'add')
    setProperty('eyeGlow.alpha', 0)
    addLuaSprite('eyeGlow', true)

    makeLuaSprite('vig', 'rage/vignette', 0, 0)
    setObjectCamera('vig', 'hud')
    setProperty('vig.alpha', 0)
    addLuaSprite('vig', true)

    makeLuaSprite('flash', '', 0, 0)
    makeGraphic('flash', screenWidth, screenHeight, 'FFFFFF')
    setObjectCamera('flash', 'other')
    setProperty('flash.alpha', 0)
    addLuaSprite('flash', true)
end

function onSongStart()
    setProperty('camZooming', true)
end

local function flash(hex, a, time)
    setProperty('flash.color', getColorFromHex(hex))
    setProperty('flash.alpha', a)
    cancelTween('flashOut')
    doTweenAlpha('flashOut', 'flash', 0, time, 'quadOut')
end

local function bump(g, h)
    setProperty('camGame.zoom', getProperty('camGame.zoom') + g)
    setProperty('camHUD.zoom', getProperty('camHUD.zoom') + h)
end

local function eyePos()
    local anim = getProperty('dad.animation.curAnim.name') or 'idle'
    local e = EYE[anim] or EYE.idle
    return getProperty('dad.x') + e[1], getProperty('dad.y') + e[2]
end

local function spawnEmber()
    local x, y = eyePos()
    emberN = emberN + 1
    local tag = 'ember' .. emberN
    makeLuaSprite(tag, 'rage/ember', x - 24 + getRandomInt(-20, 20), y - 24 + getRandomInt(-15, 15))
    setBlendMode(tag, 'add')
    addLuaSprite(tag, true)
    local s = getRandomFloat(0.6, 1.8)
    scaleObject(tag, s, s)
    doTweenY(tag .. 'Y', tag, getProperty(tag .. '.y') - getRandomInt(120, 300), getRandomFloat(0.5, 0.9), 'quadOut')
    doTweenX(tag .. 'X', tag, getProperty(tag .. '.x') - getRandomInt(30, 160), getRandomFloat(0.5, 0.9), 'sineOut')
    doTweenAlpha(tag .. 'A', tag, 0, 1.0, 'linear')
end

function onTweenCompleted(tag)
    if string.sub(tag, 1, 5) == 'ember' and string.sub(tag, -1) == 'A' then
        removeLuaSprite(string.sub(tag, 1, -2), true)
    end
end

local function noteKey(id) return math.floor(getPropertyFromGroup('notes', id, 'strumTime') + 0.5) end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    if not active() or isSustainNote then return end
    local key = noteKey(id)
    local snd = raging and rageMap[key] or voiceMap[key]
    if snd == nil then snd = (raging and 'rage_' or 'avatar_') .. dirs[direction + 1] end
    playSound(snd, 1)
    if raging then
        spawnEmber(); spawnEmber()
        cameraShake('game', 0.009, 0.12)
        cameraShake('hud', 0.005, 0.1)
        if getProperty('health') > 0.35 then setProperty('health', getProperty('health') - 0.02) end
        setProperty('eyeGlow.alpha', 1)
    else
        cameraShake('game', 0.003, 0.08)
    end
end

function goodNoteHit(id, direction, noteType, isSustainNote)
    if not active() or isSustainNote then return end
    local snd = bfMap[noteKey(id)] or ('bf_' .. dirs[direction + 1])
    playSound(snd, 0.95)
end

function onStepHit()
    if not active() then return end
    local s = curStep
    if s >= DROP_STEP and s < DROP_STEP + 8 then
        bump(0.025, 0.03)                               -- stutter punches
    elseif s == DROP_STEP + 8 then                      -- the music cuts out
        setProperty('void.alpha', 0.85)
        doTweenAlpha('gfOut', 'gf', 0, 0.5, 'quadOut')
        doTweenAlpha('hudDim', 'camHUD', 0.3, 0.5, 'quadOut')
        setProperty('defaultCamZoom', 0.95)
        cameraShake('game', 0.02, 0.3)
    elseif s == DROP_STEP + 10 then
        playSound('rage_laugh', 1)
    elseif s == DROP_STEP + 12 or s == DROP_STEP + 13 then
        cameraShake('game', 0.006, 0.15)
    elseif s == DROP_STEP + 16 then                     -- riser
        doTweenZoom('zoomIn', 'camGame', 1.15, 4 * 60 / bpm * 1.0, 'quadIn')
        setProperty('defaultCamZoom', 1.15)
    elseif s > DROP_STEP + 16 and s < RAGE_STEP and s % 2 == 0 then
        cameraShake('game', 0.002 + (s - DROP_STEP - 16) * 0.0006, 0.12)
    elseif s == RAGE_STEP then
        raging = true
        triggerEvent('Change Character', 'dad', 'my-avatar-rage')
        dadBaseX = getProperty('dad.x')
        triggerEvent('Play Animation', 'scared', 'bf')
        playSound('rage_ignite', 1)
        setProperty('void.alpha', 1)
        flash('00E5FF', 1, 0.9)
        doTweenAlpha('hudBack', 'camHUD', 1, 0.3, 'quadOut')
        doTweenAlpha('vigIn', 'vig', 1, 0.6, 'quadOut')
        cameraShake('game', 0.035, 1.0)
        cameraShake('hud', 0.02, 1.0)
        setProperty('defaultCamZoom', 0.8)
        setProperty('eyeGlow.alpha', 1)
        for i = 0, 3 do setPropertyFromGroup('opponentStrums', i, 'color', getColorFromHex('00E5FF')) end
        setHealthBarColors('00E5FF', '31B0D1')
    elseif s == END_STEP then
        raging = false; ended = true
        setProperty('dad.x', dadBaseX); setProperty('dad.alpha', 1)
        for i = 0, 3 do
            setPropertyFromGroup('opponentStrums', i, 'x', _G['defaultOpponentStrumX' .. i])
            setPropertyFromGroup('opponentStrums', i, 'y', _G['defaultOpponentStrumY' .. i])
            setPropertyFromGroup('playerStrums', i, 'x', _G['defaultPlayerStrumX' .. i])
            setPropertyFromGroup('playerStrums', i, 'y', _G['defaultPlayerStrumY' .. i])
        end
        setProperty('camHUD.angle', 0)
        flash('FFFFFF', 0.8, 1.2)
        doTweenAlpha('glowOut', 'eyeGlow', 0, 1.5, 'quadOut')
        doTweenAlpha('vigOut', 'vig', 0, 1.5, 'quadOut')
    end
end

function onBeatHit()
    if not active() then return end
    if not raging then
        if curBeat >= 8 and curStep < DROP_STEP then
            if curBeat % 4 == 0 then bump(0.03, 0.04) else bump(0.012, 0.02) end
            if curBeat % 16 == 0 then flash('FFFFFF', 0.25, 0.4) end
        end
        return
    end
    bump(curBeat % 2 == 0 and 0.03 or 0.015, 0.03)
    local rb = curBeat - RAGE_BEAT
    if rb % 4 == 2 then                                  -- teleport flicker
        playSound('rage_blink', 0.7)
        setProperty('dad.alpha', 0)
        setProperty('eyeGlow.alpha', 0)
        runTimer('blinkBack', 0.08)
    end
    if rb % 16 == 12 then                                -- eye charges up...
        charging = true
        playSound('rage_charge', 0.9)
    elseif rb > 0 and rb % 16 == 0 then                  -- ...and blasts
        charging = false
        playSound('rage_blast', 1)
        flash('00E5FF', 0.85, 0.6)
        cameraShake('game', 0.035, 0.5)
        cameraShake('hud', 0.02, 0.5)
        bump(0.12, 0.06)
        for i = 1, 8 do spawnEmber() end
        if getProperty('health') > 0.45 then setProperty('health', getProperty('health') - 0.07) end
    end
end

function onTimerCompleted(tag)
    if tag == 'blinkBack' then
        setProperty('dad.x', dadBaseX + getRandomInt(-90, 50))
        setProperty('dad.alpha', 1)
        setProperty('eyeGlow.alpha', 1)
        cameraShake('game', 0.01, 0.15)
    end
end

function onUpdate(elapsed)
    if not raging then return end
    t = t + elapsed
    sway = math.min(1, sway + elapsed * 0.25)
    for i = 0, 3 do
        setPropertyFromGroup('opponentStrums', i, 'x', _G['defaultOpponentStrumX' .. i] + math.sin(t * 3 + i * 0.8) * 30 * sway)
        setPropertyFromGroup('opponentStrums', i, 'y', _G['defaultOpponentStrumY' .. i] + math.cos(t * 4 + i) * 16 * sway)
        setPropertyFromGroup('playerStrums', i, 'x', _G['defaultPlayerStrumX' .. i] + math.sin(t * 2.5 + i * 0.6) * 20 * sway)
        setPropertyFromGroup('playerStrums', i, 'y', _G['defaultPlayerStrumY' .. i] + math.cos(t * 3.2 + i) * 10 * sway)
    end
    setProperty('camHUD.angle', math.sin(t * 1.7) * 2.5 * sway)
    local x, y = eyePos()
    local pulse = 1 + 0.18 * math.sin(t * 9) + 0.08 * math.sin(t * 23)
    if charging then pulse = pulse * 1.8 end
    scaleObject('eyeGlow', 0.75 * pulse, 0.75 * pulse)
    setProperty('eyeGlow.x', x - getProperty('eyeGlow.width') / 2)
    setProperty('eyeGlow.y', y - getProperty('eyeGlow.height') / 2)
    local a = getProperty('eyeGlow.alpha')
    if a > 0.75 then setProperty('eyeGlow.alpha', a - elapsed * 0.6) end
    setProperty('vig.alpha', 0.75 + 0.25 * math.sin(t * 3))
end
